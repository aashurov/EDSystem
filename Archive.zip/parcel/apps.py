from django.apps import AppConfig


class ParcelConfig(AppConfig):
    name = 'parcel'
