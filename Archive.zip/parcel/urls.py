from django.urls import path
from .parcelmanagement import *
urlpatterns = [
    # path('parcel/', listparcel, name='listparcel'),
]
