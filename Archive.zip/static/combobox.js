 $(document).ready(function() {
    $('#standard1').select2();
    $('#standard2').select2();
    $('#standard3').select2();
    $('#standard4').select2();
    $('#standard5').select2();
    $('#standard6').select2();

});