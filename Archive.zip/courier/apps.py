from django.apps import AppConfig


class CourierConfig(AppConfig):
    name = 'courier'
